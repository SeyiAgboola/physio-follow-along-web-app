import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";
// Tailwind assumed available. shadcn/ui + lucide-react available per environment.
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Play, Pause, SkipForward, Plus, Download, UploadCloud, Share2, Trash2, Import, Wand2 } from "lucide-react";
import { motion } from "framer-motion";

/**
 * Physio Follow‑Along – Refactored MVP
 * - Extracted hooks (speech, chime, debounced save)
 * - Global AudioContext reuse (mobile‑friendly resume)
 * - Separated Player and Builder UI from core logic
 * - Debounced localStorage writes
 */

// ---------- Types ----------
/** @typedef {{ id:string, name:string, holdSec:number, reps:number, sets:number, restSec:number, notes?:string, imageDataUrl?:string, stylizedDataUrl?:string }} Exercise */
/** @typedef {{ id:string, title:string, issueTag?:string, items:Exercise[] }} Routine */

// ---------- Utils ----------
const uid = () => Math.random().toString(36).slice(2, 10);
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const secondsToMMSS = (s) => {
  s = Math.max(0, Math.floor(s));
  const m = Math.floor(s / 60), r = s % 60; return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
};

// Encode/Decode for share links
const encodeShare = (obj) => btoa(unescape(encodeURIComponent(JSON.stringify(obj))));
const decodeShare = (str) => { try { return JSON.parse(decodeURIComponent(escape(atob(str)))); } catch { return null; } };

// Download helper
function downloadJSON(filename, obj){
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(obj, null, 2)], {type:"application/json"}));
  a.download = filename; a.click();
}

// Simple mono stylizer — left as a pure function for testability
async function stylizeToMono(dataUrl){
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      const maxW = 640; const scale = Math.min(1, maxW / img.width);
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const d = imgData.data;
      for (let i=0;i<d.length;i+=4){
        const gray = 0.2126*d[i] + 0.7152*d[i+1] + 0.0722*d[i+2];
        const v = gray > 180 ? 255 : 20; d[i]=d[i+1]=d[i+2]=v;
      }
      ctx.putImageData(imgData,0,0);
      resolve(canvas.toDataURL("image/png"));
    };
    img.src = dataUrl;
  });
}

// ---------- Global AudioContext (single instance) ----------
let _audioCtx = null;
function getAudioContext(){
  if (typeof window === "undefined") return null;
  if (!_audioCtx) _audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  return _audioCtx;
}

// ---------- Hooks ----------
function useChime(){
  const play = useCallback(async ()=>{
    try {
      const ctx = getAudioContext(); if (!ctx) return;
      if (ctx.state === "suspended") await ctx.resume();
      const o = ctx.createOscillator(); const g = ctx.createGain();
      o.type = "sine"; o.frequency.value = 880; g.gain.value = 0.001;
      g.gain.exponentialRampToValueAtTime(0.00001, ctx.currentTime + 0.4);
      o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.4);
    } catch {}
  },[]);
  return play;
}

function useSpeech(){
  const speak = useCallback((text, rate=1)=>{
    try {
      const u = new SpeechSynthesisUtterance(text); u.rate = rate;
      // Avoid queue explosion: cancel then speak a short cue
      window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
    } catch {}
  },[]);
  return speak;
}

function useDebouncedEffect(fn, deps, delay){
  const tRef = useRef(null);
  useEffect(()=>{
    if (tRef.current) clearTimeout(tRef.current);
    tRef.current = setTimeout(fn, delay);
    return () => tRef.current && clearTimeout(tRef.current);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, delay]);
}

function useInterval(callback, delay){
  const savedRef = useRef(callback);
  useEffect(()=>{ savedRef.current = callback; },[callback]);
  useEffect(()=>{ if (delay==null) return; const id=setInterval(()=>savedRef.current(), delay); return ()=>clearInterval(id); },[delay]);
}

// ---------- Preset Generators (short clinically-inspired sequences; verify with clinician) ----------
const Presets = {
  "Piriformis Syndrome": () => ([
    { id: uid(), name: "Figure-4 Glute Stretch (Left)", holdSec:45, reps:1, sets:2, restSec:15, notes:"Breathe slow, neutral back" },
    { id: uid(), name: "Figure-4 Glute Stretch (Right)", holdSec:45, reps:1, sets:2, restSec:15 },
    { id: uid(), name: "Seated Piriformis Stretch (Left)", holdSec:30, reps:1, sets:2, restSec:10 },
    { id: uid(), name: "Seated Piriformis Stretch (Right)", holdSec:30, reps:1, sets:2, restSec:10 },
  ]),
  "Sciatica (Low Back)": () => ([
    { id: uid(), name: "Nerve Glide – Slump (Left)", holdSec:2, reps:10, sets:2, restSec:20, notes:"Gentle range, no pain" },
    { id: uid(), name: "Nerve Glide – Slump (Right)", holdSec:2, reps:10, sets:2, restSec:20 },
    { id: uid(), name: "Prone Press‑Up", holdSec:2, reps:10, sets:2, restSec:20 },
  ]),
  "McGill Big 3": () => ([
    { id: uid(), name: "McGill Curl‑Up", holdSec:10, reps:5, sets:2, restSec:20, notes:"Brace core, neutral spine" },
    { id: uid(), name: "Side Plank (Left)", holdSec:10, reps:3, sets:2, restSec:20 },
    { id: uid(), name: "Side Plank (Right)", holdSec:10, reps:3, sets:2, restSec:20 },
    { id: uid(), name: "Bird‑Dog (Alt)", holdSec:10, reps:6, sets:2, restSec:20 },
  ]),
  "Shin Splints Recovery": () => ([
    { id: uid(), name: "Calf Stretch (Straight)", holdSec:30, reps:1, sets:2, restSec:15 },
    { id: uid(), name: "Calf Stretch (Bent)", holdSec:30, reps:1, sets:2, restSec:15 },
    { id: uid(), name: "Tibialis Raises", holdSec:1, reps:12, sets:2, restSec:20 },
  ]),
  "ACL Recovery (early‑mid)": () => ([
    { id: uid(), name: "Quad Set", holdSec:5, reps:10, sets:2, restSec:20 },
    { id: uid(), name: "Straight Leg Raise", holdSec:2, reps:10, sets:2, restSec:20 },
    { id: uid(), name: "Heel Slides", holdSec:2, reps:10, sets:2, restSec:20 },
  ]),
};

// ---------- Storage ----------
const LS_KEY = "physio-follow-along:v2";
const loadLS = () => { try { const s = localStorage.getItem(LS_KEY); return s? JSON.parse(s): null; } catch { return null; } };
const saveLS = (state) => { try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch {} };

// ---------- Playback Engine helpers ----------
function computeTotalSeconds(routine){
  return routine.items.reduce((sum, ex) => sum + (ex.holdSec * Math.max(1, ex.reps) * Math.max(1, ex.sets)) + ex.restSec * Math.max(0, ex.sets - 1), 0);
}

// ---------- App ----------
export default function App(){
  const initial = loadFromLocationHash() || loadLS()?.routine || { id: uid(), title: "My Routine", issueTag: "Custom", items: [] };
  const [routine, setRoutine] = useState(/** @type {Routine} */(initial));

  // Debounced persistence
  useDebouncedEffect(()=> saveLS({ routine }), [routine], 300);

  // Share link hydration
  useEffect(()=>{ if (location.hash.startsWith("#share:")) history.replaceState(null, "", location.pathname); },[]);

  const exportJSONClick = () => downloadJSON(`${routine.title.replace(/\s+/g,"_")}.json`, { title:routine.title, issueTag:routine.issueTag, items:routine.items });
  const createShareLink = () => {
    const out = { title:routine.title, issueTag:routine.issueTag, items:routine.items };
    const hash = `share:${encodeShare(out)}`; history.replaceState(null, "", `#${hash}`);
    navigator.clipboard?.writeText(location.href); alert("Share link copied to clipboard.");
  };

  const loadPreset = (name) => { const gen = Presets[name]; if (!gen) return; setRoutine({ id:uid(), title: `${name} – Quick`, issueTag:name, items: gen() }); };
  const addExercise = (preset={}) => setRoutine(r=> ({...r, items:[...r.items, { id:uid(), name:preset.name||"New Exercise", holdSec:preset.holdSec??30, reps:preset.reps??1, sets:preset.sets??1, restSec:preset.restSec??10, notes:preset.notes||"" }]}));
  const updateExercise = (id, patch) => setRoutine(r=> ({...r, items:r.items.map(it=> it.id===id ? {...it, ...patch}: it)}));
  const removeExercise = (id) => setRoutine(r=> ({...r, items:r.items.filter(it=> it.id!==id)}));
  const moveExercise = (id, dir) => setRoutine(r=> { const i=r.items.findIndex(x=>x.id===id); if(i<0) return r; const j=clamp(i+dir,0,r.items.length-1); const copy=r.items.slice(); const [it]=copy.splice(i,1); copy.splice(j,0,it); return {...r, items:copy}; });

  const importJSON = (file)=>{
    const reader = new FileReader();
    reader.onload = ()=>{ try { const obj = JSON.parse(String(reader.result)); if(!obj.title||!Array.isArray(obj.items)) throw new Error(); setRoutine({ id:uid(), ...obj }); } catch { alert("Could not import file"); } };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-50">
      <div className="max-w-5xl mx-auto p-4 sm:p-6">
        <header className="flex items-center justify-between gap-2 mb-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold">Physio Follow‑Along</h1>
            <p className="text-neutral-400 text-sm">Personalised, timed rehab sequences. Clean visuals. Zero backend.</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" className="rounded-2xl" onClick={exportJSONClick}><Download className="w-4 h-4 mr-2"/>Export</Button>
            <label className="inline-flex items-center gap-2">
              <Input type="file" accept="application/json" className="hidden" onChange={(e)=> e.target.files && importJSON(e.target.files[0])} />
              <Button variant="outline" className="rounded-2xl"><Import className="w-4 h-4 mr-2"/>Import</Button>
            </label>
            <Button variant="outline" className="rounded-2xl" onClick={createShareLink}><Share2 className="w-4 h-4 mr-2"/>Share</Button>
          </div>
        </header>

        <Tabs defaultValue="builder" className="w-full">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 bg-neutral-900">
            <TabsTrigger value="builder">Builder</TabsTrigger>
            <TabsTrigger value="player">Player</TabsTrigger>
            <TabsTrigger value="presets" className="hidden sm:block">Presets</TabsTrigger>
          </TabsList>

          <TabsContent value="builder" className="mt-4">
            <Builder
              routine={routine}
              addExercise={addExercise}
              loadPreset={loadPreset}
              updateExercise={updateExercise}
              removeExercise={removeExercise}
              moveExercise={moveExercise}
              setRoutine={setRoutine}
            />
          </TabsContent>

          <TabsContent value="player" className="mt-4">
            <Player routine={routine} />
          </TabsContent>

          <TabsContent value="presets" className="mt-4">
            <div className="grid sm:grid-cols-2 gap-3">
              {Object.keys(Presets).map((name) => (
                <Card key={name} className="bg-neutral-900/60 border-neutral-800 rounded-2xl">
                  <CardHeader><CardTitle>{name}</CardTitle></CardHeader>
                  <CardContent>
                    <div className="text-sm text-neutral-400 mb-2">Quick 5–10 minute starter set. Customise after loading.</div>
                    <Button className="rounded-2xl" onClick={()=>loadPreset(name)}>Load</Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <footer className="text-center text-neutral-500 text-xs mt-6">
          Built as an MVP. Not medical advice. Confirm parameters with your clinician.
        </footer>
      </div>
    </div>
  );
}

// ---------- Builder ----------
function Builder({ routine, addExercise, loadPreset, updateExercise, removeExercise, moveExercise, setRoutine }){
  const onUploadImage = async (id, file) => {
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = String(reader.result);
      const stylized = await stylizeToMono(dataUrl);
      updateExercise(id, { imageDataUrl: dataUrl, stylizedDataUrl: stylized });
    };
    reader.readAsDataURL(file);
  };

  const totalSeconds = useMemo(()=> computeTotalSeconds(routine), [routine]);

  return (
    <Card className="bg-neutral-900/60 border-neutral-800 rounded-2xl">
      <CardHeader>
        <CardTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center gap-2">
            <Input className="bg-neutral-800 border-neutral-700" value={routine.title} onChange={e=>setRoutine(r=>({...r, title:e.target.value}))} />
            <Select value={routine.issueTag || "Custom"} onValueChange={(v)=> setRoutine(r=>({...r, issueTag:v}))}>
              <SelectTrigger className="w-[170px] bg-neutral-800 border-neutral-700"><SelectValue placeholder="Tag"/></SelectTrigger>
              <SelectContent className="bg-neutral-900 border-neutral-800">
                {Object.keys(Presets).map(k => <SelectItem key={k} value={k}>{k}</SelectItem>)}
                <SelectItem value="Custom">Custom</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="text-sm text-neutral-400">Total: {secondsToMMSS(totalSeconds)}</div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-4">
          <Button onClick={()=>addExercise()} className="rounded-2xl"><Plus className="w-4 h-4 mr-2"/>Add Exercise</Button>
          <Select onValueChange={loadPreset}>
            <SelectTrigger className="w-[220px] bg-neutral-800 border-neutral-700"><SelectValue placeholder="Load preset routine"/></SelectTrigger>
            <SelectContent className="bg-neutral-900 border-neutral-800">
              {Object.keys(Presets).map(name => <SelectItem value={name} key={name}>{name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-3">
          {routine.items.map((ex) => (
            <motion.div key={ex.id} layout initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} className="rounded-2xl border border-neutral-800 bg-neutral-900 p-3">
              <div className="flex items-start gap-3">
                <div className="w-24 h-24 rounded-xl bg-neutral-800 overflow-hidden flex items-center justify-center text-xs text-neutral-400">
                  {ex.stylizedDataUrl ? (
                    <img src={ex.stylizedDataUrl} alt="exercise" className="w-full h-full object-cover"/>
                  ) : ex.imageDataUrl ? (
                    <img src={ex.imageDataUrl} alt="exercise" className="w-full h-full object-cover"/>
                  ) : (
                    <div className="flex flex-col items-center">
                      <Wand2 className="w-5 h-5 mb-1"/>
                      No image
                    </div>
                  )}
                </div>
                <div className="flex-1 grid grid-cols-1 sm:grid-cols-6 gap-2">
                  <Input className="sm:col-span-2 bg-neutral-800 border-neutral-700" value={ex.name} onChange={e=>updateExercise(ex.id,{name:e.target.value})} />
                  <div className="sm:col-span-1">
                    <Label className="text-xs text-neutral-400">Hold (s)</Label>
                    <Input type="number" min={1} className="bg-neutral-800 border-neutral-700" value={ex.holdSec} onChange={e=>updateExercise(ex.id,{holdSec:parseInt(e.target.value||"0",10)})} />
                  </div>
                  <div className="sm:col-span-1">
                    <Label className="text-xs text-neutral-400">Reps</Label>
                    <Input type="number" min={1} className="bg-neutral-800 border-neutral-700" value={ex.reps} onChange={e=>updateExercise(ex.id,{reps:parseInt(e.target.value||"0",10)})} />
                  </div>
                  <div className="sm:col-span-1">
                    <Label className="text-xs text-neutral-400">Sets</Label>
                    <Input type="number" min={1} className="bg-neutral-800 border-neutral-700" value={ex.sets} onChange={e=>updateExercise(ex.id,{sets:parseInt(e.target.value||"0",10)})} />
                  </div>
                  <div className="sm:col-span-1">
                    <Label className="text-xs text-neutral-400">Rest (s)</Label>
                    <Input type="number" min={0} className="bg-neutral-800 border-neutral-700" value={ex.restSec} onChange={e=>updateExercise(ex.id,{restSec:parseInt(e.target.value||"0",10)})} />
                  </div>
                  <div className="sm:col-span-6">
                    <Textarea className="bg-neutral-800 border-neutral-700" rows={2} placeholder="Notes / cues" value={ex.notes||""} onChange={e=>updateExercise(ex.id,{notes:e.target.value})}/>
                  </div>
                  <div className="sm:col-span-6 flex items-center gap-2 flex-wrap">
                    <label className="inline-flex items-center gap-2">
                      <Input type="file" accept="image/*" className="hidden" onChange={(e)=> e.target.files && onUploadImage(ex.id, e.target.files[0]) } />
                      <Button variant="outline" className="rounded-2xl"><UploadCloud className="w-4 h-4 mr-2"/>Upload Image</Button>
                    </label>
                    {ex.imageDataUrl && (
                      <Button variant="secondary" className="rounded-2xl" onClick={async()=> updateExercise(ex.id,{stylizedDataUrl: await stylizeToMono(ex.imageDataUrl)})}>Simplify</Button>
                    )}
                    <div className="ml-auto flex items-center gap-2">
                      <Button variant="outline" className="rounded-2xl" onClick={()=>moveExercise(ex.id,-1)}>↑</Button>
                      <Button variant="outline" className="rounded-2xl" onClick={()=>moveExercise(ex.id,+1)}>↓</Button>
                      <Button variant="destructive" className="rounded-2xl" onClick={()=>removeExercise(ex.id)}><Trash2 className="w-4 h-4"/></Button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
          {routine.items.length===0 && <div className="text-neutral-400 text-sm">Add exercises or load a preset to get started.</div>}
        </div>
      </CardContent>
    </Card>
  );
}

// ---------- Player ----------
function Player({ routine }){
  const speak = useSpeech();
  const chime = useChime();

  const [playing, setPlaying] = useState(false);
  const [announce, setAnnounce] = useState(true);
  const [cursor, setCursor] = useState({ idx:0, set:1, rep:1, phase:"work" });
  const [secLeft, setSecLeft] = useState(0);

  const cur = routine.items[cursor.idx] || null;
  const totalSeconds = useMemo(()=> computeTotalSeconds(routine), [routine]);

  const pct = useMemo(()=>{
    const doneBefore = routine.items.slice(0, cursor.idx).reduce((s, ex) => s + (ex.holdSec * Math.max(1, ex.reps) * Math.max(1, ex.sets)) + ex.restSec * Math.max(0, ex.sets - 1), 0);
    const curTotal = cur ? (cursor.phase === "work" ? cur.holdSec : cur.restSec) : 0;
    const curElapsed = cur ? (curTotal - secLeft) : 0;
    return totalSeconds ? Math.min(100, Math.round(((doneBefore + curElapsed)/totalSeconds)*100)) : 0;
  }, [routine, cursor, cur, secLeft, totalSeconds]);

  const next = useCallback(async ()=>{
    const item = cur; if (!item) return;
    if (cursor.phase === "work"){
      if (cursor.rep < item.reps){
        setCursor(c => ({...c, rep:c.rep+1})); setSecLeft(item.holdSec);
        if (announce) speak(`${item.name}, rep ${cursor.rep+1} of ${item.reps}`); await chime();
      } else if (cursor.set < item.sets){
        setCursor(c => ({...c, set:c.set+1, rep:1, phase: item.restSec>0? "rest":"work" }));
        setSecLeft(item.restSec>0 ? item.restSec : item.holdSec);
        if (item.restSec>0 && announce) speak(`Rest ${item.restSec} seconds`); await chime();
      } else {
        const nextIdx = cursor.idx + 1;
        if (nextIdx >= routine.items.length){ setPlaying(false); setSecLeft(0); if (announce) speak("Routine complete. Nice work."); await chime(); }
        else { const n = routine.items[nextIdx]; setCursor({ idx:nextIdx, set:1, rep:1, phase:"work" }); setSecLeft(n.holdSec); if (announce) speak(`Next: ${n.name}`); await chime(); }
      }
    } else { // rest → work
      setCursor(c => ({...c, phase:"work", rep:1})); setSecLeft(item.holdSec);
      if (announce) speak(`${item.name}, set ${cursor.set} start`); await chime();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cur, cursor.idx, cursor.rep, cursor.set, cursor.phase, routine.items, announce, speak, chime]);

  const start = async ()=>{
    if (routine.items.length===0) return;
    const first = routine.items[0]; setCursor({ idx:0, set:1, rep:1, phase:"work" }); setSecLeft(first.holdSec);
    setPlaying(true); if (announce) speak(`Starting: ${first.name}`); await chime();
  };
  const pause = ()=> setPlaying(false);
  const resume = ()=> setPlaying(true);
  const skipExercise = async ()=>{
    if (cursor.idx + 1 < routine.items.length){
      const n = routine.items[cursor.idx + 1]; setCursor({ idx:cursor.idx+1, set:1, rep:1, phase:"work" }); setSecLeft(n.holdSec);
      if (announce) speak(`Skipping to ${n.name}`);
    } else { setPlaying(false); setSecLeft(0); }
  };

  useInterval(()=> {
    if (!playing) return;
    setSecLeft(s => { if (s>1) return s-1; next(); return 0; });
  }, 1000);

  return (
    <Card className="bg-neutral-900/60 border-neutral-800 rounded-2xl">
      <CardContent className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="sm:w-2/3 space-y-3">
            <div className="aspect-video rounded-2xl bg-neutral-800 flex items-center justify-center overflow-hidden">
              {cur?.stylizedDataUrl || cur?.imageDataUrl ? (
                <img src={cur.stylizedDataUrl || cur.imageDataUrl} alt="current" className="w-full h-full object-cover"/>
              ) : (
                <div className="text-center text-neutral-400 px-6">{cur ? cur.name : (routine.title || "Routine")}</div>
              )}
            </div>

            <div className="rounded-2xl bg-neutral-800 p-4">
              <div className="flex items-baseline justify-between">
                <div className="text-lg font-semibold truncate max-w-[70%]">{cur ? cur.name : (routine.title || "Routine")}</div>
                <div className="text-sm text-neutral-400">{secondsToMMSS(secLeft)}</div>
              </div>
              <Progress value={pct} className="h-2 mt-3 bg-neutral-700" />
              <div className="flex items-center gap-3 mt-3 text-sm text-neutral-400">
                <span>Set {cursor.set}/{cur?.sets || 0}</span>
                <span>•</span>
                <span>Rep {cursor.rep}/{cur?.reps || 0}</span>
                <span>•</span>
                <span>{cursor.phase === "work" ? "Hold" : "Rest"}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {!playing ? (
                <Button onClick={start} className="flex-1 rounded-2xl text-lg"><Play className="w-5 h-5 mr-2"/>Start</Button>
              ) : (
                <>
                  <Button onClick={pause} variant="secondary" className="flex-1 rounded-2xl text-lg"><Pause className="w-5 h-5 mr-2"/>Pause</Button>
                  <Button onClick={resume} className="flex-1 rounded-2xl text-lg"><Play className="w-5 h-5 mr-2"/>Resume</Button>
                </>
              )}
              <Button onClick={next} variant="outline" className="rounded-2xl"><SkipForward className="w-5 h-5"/></Button>
              <Button onClick={skipExercise} variant="outline" className="rounded-2xl">Skip</Button>
            </div>
          </div>

          <div className="sm:w-1/3 space-y-3">
            <div className="rounded-2xl bg-neutral-800 p-4">
              <div className="font-semibold mb-2">Next up</div>
              <div className="text-sm text-neutral-300 min-h-[2lh]">
                {cursor.idx + 1 < routine.items.length ? routine.items[cursor.idx + 1].name : "—"}
              </div>
              <div className="text-xs text-neutral-500 mt-1">Total {secondsToMMSS(totalSeconds)}</div>
            </div>

            <div className="rounded-2xl bg-neutral-800 p-4">
              <div className="font-semibold mb-2">Notes</div>
              <div className="text-sm text-neutral-300 min-h-[4lh] whitespace-pre-wrap">{cur?.notes || "—"}</div>
            </div>

            <div className="rounded-2xl bg-neutral-800 p-4">
              <div className="font-semibold mb-2">Voice cues</div>
              <div className="text-sm text-neutral-400">Text‑to‑speech uses your device audio. Ensure ringer is on.</div>
              <div className="mt-2">
                <label className="inline-flex items-center gap-2">
                  <input type="checkbox" className="accent-white" checked={announce} onChange={(e)=>setAnnounce(e.target.checked)} />
                  <span className="text-sm">Enable voice cues</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ---------- Helpers ----------
function loadFromLocationHash(){
  const hash = location.hash.replace(/^#/, "");
  if (hash.startsWith("share:")){
    const obj = decodeShare(hash.slice(6));
    if (obj?.title && Array.isArray(obj.items)) return { id:uid(), ...obj };
  }
  return null;
}
